package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import model.Produtos;
import util.ConectaDB;


public class ProdutoDAO {

    public boolean inserir (Produtos p_us) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
            //String sql = "Insert into produtos (codigo, nome, renda, nasc) values(987654, 'José da Silva', 9500, '1981/03/22')";
            String sql = "Insert into produtos (produto, descricao, preco, loja,avaliacao) values('" + p_us.getProd() + "', '" + 
                                                                                     p_us.getDesc() + "', " + 
                                                                                    p_us.getPreco() + ", " + p_us.getLoja() +", "+ p_us.getAvali() +")";
                                                                                            // SimpleDateFormat("dd/MM/yyyy").format(func.getNasc())
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
    
    //Consultas
    public List consultar() throws ClassNotFoundException, ParseException{
        List lista = new ArrayList();
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM produtos";
            String sql = "SELECT * FROM produtos";
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               Produtos prod = new Produtos();
               prod.setId( Integer.parseInt( rs.getString("id") ));
               prod.setProd( rs.getString("produto"));
               prod.setDesc(rs.getString("descricao"));
               prod.setPreco(Double.parseDouble(rs.getString("preco")));
               prod.setLoja(rs.getString("loja"));
               prod.setAvali( Integer.parseInt( rs.getString("avaliacao") ));
               lista.add(prod);
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return lista;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
     public Produtos pesquisar(Produtos p_us) throws ClassNotFoundException, ParseException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM produtos WHERE pk_id = 7";
            String sql = "SELECT * FROM produtos WHERE id = " + p_us.getId();
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               p_us.setId( Integer.parseInt( rs.getString("id") ));
               p_us.setProd(rs.getString("produto"));
               p_us.setDesc(rs.getString("descricao"));
               p_us.setPreco(Double.parseDouble(rs.getString("preco")));
               p_us.setLoja( rs.getString("loja"));
               p_us.setAvali(Integer.parseInt( rs.getString("avaliacao")));
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return p_us;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
    //excluir_id
    public boolean excluir_id(Produtos p_us) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();            
            String sql = "DELETE from produtos WHERE id = " + p_us.getId();          
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
    
    //alterar
    public boolean alterar(Produtos p_us) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
          //String sql = "UPDATE produtos SET nome='Amanda de Souza', renda= 7500, nasc='2020/04/20' WHERE codigo = 700";
            String sql = "UPDATE produtos SET produto='" + p_us.getProd() + "', descricao= '" +p_us.getDesc()+ "', preco=" + p_us.getPreco()+ ", loja='" + p_us.getLoja()+ "', avaliacao=" + p_us.getAvali()+
                                                                          " WHERE id = " + p_us.getId();                                                                                                                       
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
}