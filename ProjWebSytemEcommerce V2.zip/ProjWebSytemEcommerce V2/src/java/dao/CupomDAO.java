package dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import model.Cupom;
import util.ConectaDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class CupomDAO {

    public boolean inserir (Cupom p_cp) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
            //String sql = "Insert into Cupom (codigo, nome, renda, nasc) values(987654, 'José da Silva', 9500, '1981/03/22')";
            String sql = "Insert into cupons (desconto, produto, loja, validade) values(" + p_cp.getDesconto() + ", " + 
                                                                                     p_cp.getProduto() + ", " + 
                                                                                    p_cp.getLoja() + ", '"+ new SimpleDateFormat("yyyy/MM/dd").format(p_cp.getValidade())+"')";
                                                                                            // SimpleDateFormat("dd/MM/yyyy").format(func.getNasc())
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
    
     public List<Cupom> consultar_datas(String dataInicial, String dataFinal) throws SQLException, ParseException, ClassNotFoundException {
        
        
        
        
        
        List<Cupom> resultados = new ArrayList();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try(Connection conexao = ConectaDB.conectar();){
            // Converte as datas de String para java.sql.Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date sqlDataInicial =  (java.util.Date) sdf.parse(dataInicial);
            java.util.Date sqlDataFinal =  (java.util.Date) sdf.parse(dataFinal);

            // Consulta SQL com parâmetros
            String sql = "SELECT * FROM cupons WHERE validade BETWEEN ? AND ?";
            preparedStatement = conexao.prepareStatement(sql);
             preparedStatement.setDate(1, new java.sql.Date(sqlDataInicial.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(sqlDataFinal.getTime()));

            rs = preparedStatement.executeQuery();
            
            
            // Processa os resultados
           int n_reg = 0;
            
          while (rs.next()) {
              Cupom cp = new Cupom();
                cp.setTicket(Integer.parseInt( rs.getString("ticket") ));
               cp.setDesconto(Double.valueOf(rs.getString("desconto")));
               cp.setProduto(rs.getString("produto"));
               cp.setLoja(rs.getString("loja"));
               cp.setValidade(rs.getDate("validade"));
            
            resultados.add(cp);
            n_reg++;
 
          }
          if (n_reg == 0){
                return null;
            }else{
                return resultados;
            }   
        
        } catch (SQLException e) {
            
             return null;
       
            }
       
         }
    
    //Consultas
    public List consultar() throws ClassNotFoundException, ParseException{
        List lista = new ArrayList();
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM Cupom";
            String sql = "SELECT * FROM cupons";
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               Cupom cp = new Cupom();
               cp.setTicket(Integer.parseInt( rs.getString("ticket") ));
               cp.setDesconto(Double.valueOf(rs.getString("desconto")));
               cp.setProduto(rs.getString("produto"));
               cp.setLoja(rs.getString("loja"));
               cp.setValidade(rs.getDate("validade"));
               lista.add(cp);
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return lista;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
    
     public Cupom pesquisar(Cupom cp) throws ClassNotFoundException, ParseException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement(); //Cria uma instrução
            //String sql = "SELECT * FROM Cupom WHERE pk_Ticket = 7";
            String sql = "SELECT * FROM cupons WHERE ticket = " + cp.getTicket();
            ResultSet rs = stmt.executeQuery(sql); // Select
            
            int n_reg = 0;
            while (rs.next()){
               cp.setTicket(Integer.parseInt( rs.getString("ticket") ));
               cp.setDesconto(Double.valueOf(rs.getString("desconto")));
               cp.setProduto(rs.getString("produto"));
               cp.setLoja(rs.getString("loja"));
               cp.setValidade(rs.getDate("validade"));
               n_reg++;
            }
                
            if (n_reg == 0){
                return null;
            }else{
                return cp;
            }            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);    
            return null;
        }               
    }
    
    //excluir_Ticket
    public boolean excluir_Ticket(Cupom p_cp) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();            
            String sql = "DELETE from cupons WHERE ticket = " + p_cp.getTicket();          
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
    
    //alterar
    public boolean alterar(Cupom p_cp) throws ClassNotFoundException{
        //Conectar
        Connection conexao = null;
        try{
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
          //String sql = "UPDATE Cupom SET nome='Amanda de Souza', renda= 7500, nasc='2020/04/20' WHERE codigo = 700";
            String sql = "UPDATE cupons SET desconto='" + p_cp.getDesconto() + "', produto= " +p_cp.getProduto()+ ", loja=" + p_cp.getLoja()+ ", validade='" + new SimpleDateFormat("yyyy/MM/dd").format(p_cp.getValidade())+ 
                                                                          "' WHERE ticket = " + p_cp.getTicket();                                                                                                                       
            stmt.executeUpdate(sql); // Insert - Update - Delete
            return true;
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }
}
