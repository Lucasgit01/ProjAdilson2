package dao;

import java.sql.*;
import model.Usuario;
import java.util.*;
import util.ConectaDB;
/*import java.sql.DriverManager;
import java.sql.PreparedStatement;        
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;*/


public class UsuariosDAO {
    
public boolean verificar(Usuario p_us) throws ClassNotFoundException{
        Connection conexao = null;
        try{
             
            conexao = ConectaDB.conectar(); //Abre a conexão
            Statement stmt = conexao.createStatement();
            //String sql = "Insert into Lojas (codigo, nome, renda, nasc) values(987654, 'José da Silva', 9500, '1981/03/22')";
            String sql = "Select * From usuario where usuario ='"+p_us.getUser()+"' and senha= '"+p_us.getSenha()+"' ";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()){
              p_us.setNome(rs.getString("nome")); 
              p_us.setSetor(rs.getString("setor"));
                 return true;
            }else{
            return false;
            }
            
        }
        catch(SQLException ex){
            System.out.println("Erro SQL: " + ex);
            return false;
        }               
    }

}
