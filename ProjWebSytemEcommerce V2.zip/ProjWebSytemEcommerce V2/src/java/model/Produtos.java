/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to changetthis.license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this.template
 */
package model;

/**
 *
 * @author alunocmc
 */
public class Produtos {
    // Atrib.
    private int id;
    private String produto;
    private String descricao;
    private double preco;  
    private String loja;
    private int avaliacao;
    
    // Métodos
    public Produtos() {
    }
    public Produtos(int p_id, String p_produto, String p_descricao, double p_preco, String p_loja, int p_avaliacao){
        this.id = p_id;
        this.produto = p_produto;
        this.descricao = p_descricao;
        this.preco = p_preco;
        this.loja = p_loja;
        this.avaliacao = p_avaliacao;
    }

    public void setId(int  p_id) {
        this.id = p_id;    
    }
    public void setProd(String p_produto) {
        this.produto = p_produto;    
    }
    public void setDesc(String p_descricao) {
        this.descricao = p_descricao;    
    }
    public void setPreco(double p_preco) {
        this.preco = p_preco;
    }
    public void setLoja(String p_loja) {
        this.loja = p_loja;
    }
     public void setAvali(int  p_avaliacao) {
        this.avaliacao = p_avaliacao;    
    }
    
    public int getId() {
        return this.id;
    }
    public String getProd() {
        return this.produto;
    }
    public String getDesc() {
        return this.descricao;
    }
    public double getPreco() {
        return this.preco;
    }   
    public String getLoja() {
        return this.loja;
    }
    public int getAvali() {
        return this.avaliacao;
    }
}
