/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

public class Cupom {

    private int ticket;
    private Double desconto;
    private String produto;
    private String loja;
    private Date validade;

    public Cupom(){}
    
    public Cupom(int ticket, Double desconto, String produto, String loja, Date validade) {
        this.ticket = ticket;
        this.desconto = desconto;
        this.produto = produto;
        this.loja = loja;
        this.validade = validade;
    }

    public int getTicket() {
        return ticket;
    }

    public Double getDesconto() {
        return desconto;
    }

    public String getProduto() {
        return produto;
    }

    public String getLoja() {
        return loja;
    }

    public Date getValidade() {
        return validade;
    }

    public void setTicket(int ticket) {
        this.ticket = ticket;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public void setLoja(String loja) {
        this.loja = loja;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }
    
}

